package com.example.praktisi2

data class dataClass(var dataImage:Int, var dataTitle1:String, var dataTitle2:String)
